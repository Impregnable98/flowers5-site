<?php

class msProductOption extends xPDOObject
{
}
